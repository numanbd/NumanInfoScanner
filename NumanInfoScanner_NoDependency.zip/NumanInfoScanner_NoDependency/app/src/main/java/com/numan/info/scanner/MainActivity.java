package com.numan.info.scanner;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_CAMERA = 11;
    private static final int REQ_GALLERY = 12;
    private static final int REQ_PERMISSION = 99;

    private final ArrayList<Bitmap> pages = new ArrayList<>();
    private ImageView preview;
    private TextView status;
    private int selectedIndex = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_PERMISSION);
        }
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(245, 247, 250));
        root.setPadding(20, 28, 20, 20);

        TextView title = new TextView(this);
        title.setText("Numan Info Scanner");
        title.setTextSize(26);
        title.setTextColor(Color.rgb(20, 90, 45));
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 0, 0, 8);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView sub = new TextView(this);
        sub.setText("Scan documents, enhance pages, and create PDF");
        sub.setTextSize(14);
        sub.setTextColor(Color.DKGRAY);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, 0, 0, 18);
        root.addView(sub, new LinearLayout.LayoutParams(-1, -2));

        preview = new ImageView(this);
        preview.setBackgroundColor(Color.WHITE);
        preview.setScaleType(ImageView.ScaleType.FIT_CENTER);
        root.addView(preview, new LinearLayout.LayoutParams(-1, 0, 1));

        status = new TextView(this);
        status.setText("No page added yet");
        status.setTextSize(15);
        status.setTextColor(Color.BLACK);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, 12, 0, 12);
        root.addView(status, new LinearLayout.LayoutParams(-1, -2));

        ScrollView scroll = new ScrollView(this);
        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(buttons);

        buttons.addView(btn("Scan with Camera", v -> openCamera()));
        buttons.addView(btn("Import from Gallery", v -> openGallery()));
        buttons.addView(btn("Enhance / Clear", v -> applyEnhance()));
        buttons.addView(btn("Black & White", v -> applyBlackWhite()));
        buttons.addView(btn("Rotate Page", v -> rotatePage()));
        buttons.addView(btn("Remove Current Page", v -> removePage()));
        buttons.addView(btn("Create PDF in Downloads", v -> createPdf()));
        buttons.addView(btn("Clear All Pages", v -> clearAll()));

        root.addView(scroll, new LinearLayout.LayoutParams(-1, -2));
        setContentView(root);
        updatePreview();
    }

    private Button btn(String text, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(16);
        b.setPadding(10, 8, 10, 8);
        b.setOnClickListener(listener);
        return b;
    }

    private void openCamera() {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(intent, REQ_CAMERA);
        } else {
            toast("Camera app not found");
        }
    }

    private void openGallery() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, REQ_GALLERY);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null) return;
        try {
            Bitmap bmp = null;
            if (requestCode == REQ_CAMERA) {
                Object obj = data.getExtras() != null ? data.getExtras().get("data") : null;
                if (obj instanceof Bitmap) bmp = (Bitmap) obj;
            } else if (requestCode == REQ_GALLERY) {
                Uri uri = data.getData();
                if (uri != null) {
                    InputStream is = getContentResolver().openInputStream(uri);
                    bmp = BitmapFactory.decodeStream(is);
                    if (is != null) is.close();
                }
            }
            if (bmp != null) {
                pages.add(scaleForMemory(bmp));
                selectedIndex = pages.size() - 1;
                updatePreview();
                toast("Page added");
            }
        } catch (Exception e) {
            toast("Failed to add page: " + e.getMessage());
        }
    }

    private Bitmap scaleForMemory(Bitmap src) {
        int max = 1600;
        int w = src.getWidth();
        int h = src.getHeight();
        if (w <= max && h <= max) return src;
        float ratio = Math.min((float) max / w, (float) max / h);
        return Bitmap.createScaledBitmap(src, Math.round(w * ratio), Math.round(h * ratio), true);
    }

    private void updatePreview() {
        if (selectedIndex >= 0 && selectedIndex < pages.size()) {
            preview.setImageBitmap(pages.get(selectedIndex));
            status.setText("Page " + (selectedIndex + 1) + " of " + pages.size());
        } else {
            preview.setImageDrawable(null);
            status.setText("No page added yet");
        }
    }

    private Bitmap current() {
        if (selectedIndex < 0 || selectedIndex >= pages.size()) {
            toast("Add a page first");
            return null;
        }
        return pages.get(selectedIndex);
    }

    private void applyEnhance() {
        Bitmap src = current();
        if (src == null) return;
        Bitmap out = Bitmap.createBitmap(src.getWidth(), src.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(out);
        Paint paint = new Paint();
        ColorMatrix matrix = new ColorMatrix(new float[]{
                1.25f, 0, 0, 0, 10,
                0, 1.25f, 0, 0, 10,
                0, 0, 1.25f, 0, 10,
                0, 0, 0, 1, 0
        });
        paint.setColorFilter(new ColorMatrixColorFilter(matrix));
        canvas.drawBitmap(src, 0, 0, paint);
        pages.set(selectedIndex, out);
        updatePreview();
    }

    private void applyBlackWhite() {
        Bitmap src = current();
        if (src == null) return;
        Bitmap out = Bitmap.createBitmap(src.getWidth(), src.getHeight(), Bitmap.Config.ARGB_8888);
        for (int y = 0; y < src.getHeight(); y++) {
            for (int x = 0; x < src.getWidth(); x++) {
                int c = src.getPixel(x, y);
                int gray = (Color.red(c) + Color.green(c) + Color.blue(c)) / 3;
                int bw = gray > 145 ? 255 : 0;
                out.setPixel(x, y, Color.rgb(bw, bw, bw));
            }
        }
        pages.set(selectedIndex, out);
        updatePreview();
    }

    private void rotatePage() {
        Bitmap src = current();
        if (src == null) return;
        android.graphics.Matrix m = new android.graphics.Matrix();
        m.postRotate(90);
        Bitmap out = Bitmap.createBitmap(src, 0, 0, src.getWidth(), src.getHeight(), m, true);
        pages.set(selectedIndex, out);
        updatePreview();
    }

    private void removePage() {
        if (current() == null) return;
        pages.remove(selectedIndex);
        selectedIndex = pages.isEmpty() ? -1 : Math.max(0, selectedIndex - 1);
        updatePreview();
    }

    private void clearAll() {
        pages.clear();
        selectedIndex = -1;
        updatePreview();
    }

    private void createPdf() {
        if (pages.isEmpty()) {
            toast("Add at least one page");
            return;
        }
        String name = "NumanScanner_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".pdf";
        PdfDocument pdf = new PdfDocument();
        try {
            for (int i = 0; i < pages.size(); i++) {
                Bitmap bmp = pages.get(i);
                int pageWidth = 595;
                int pageHeight = 842;
                PdfDocument.PageInfo info = new PdfDocument.PageInfo.Builder(pageWidth, pageHeight, i + 1).create();
                PdfDocument.Page page = pdf.startPage(info);
                Canvas canvas = page.getCanvas();
                Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
                float scale = Math.min((float) pageWidth / bmp.getWidth(), (float) pageHeight / bmp.getHeight());
                float left = (pageWidth - bmp.getWidth() * scale) / 2f;
                float top = (pageHeight - bmp.getHeight() * scale) / 2f;
                canvas.drawColor(Color.WHITE);
                canvas.save();
                canvas.translate(left, top);
                canvas.scale(scale, scale);
                canvas.drawBitmap(bmp, 0, 0, p);
                canvas.restore();
                pdf.finishPage(page);
            }

            OutputStream os;
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Downloads.DISPLAY_NAME, name);
                values.put(MediaStore.Downloads.MIME_TYPE, "application/pdf");
                values.put(MediaStore.Downloads.RELATIVE_PATH, "Download/NumanInfoScanner");
                Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                os = getContentResolver().openOutputStream(uri);
            } else {
                File dir = new File(android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS), "NumanInfoScanner");
                if (!dir.exists()) dir.mkdirs();
                os = new FileOutputStream(new File(dir, name));
            }
            pdf.writeTo(os);
            if (os != null) os.close();
            toast("PDF saved: Downloads/NumanInfoScanner/" + name);
        } catch (Exception e) {
            toast("PDF failed: " + e.getMessage());
        } finally {
            pdf.close();
        }
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
    }
}
