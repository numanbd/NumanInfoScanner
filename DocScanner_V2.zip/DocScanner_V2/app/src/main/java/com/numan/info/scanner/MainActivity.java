package com.numan.info.scanner;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_CAMERA = 11;
    private static final int REQ_GALLERY = 12;
    private static final int REQ_PERMISSION = 99;

    private final ArrayList<Bitmap> pages = new ArrayList<>();
    private ImageView preview;
    private TextView status;
    private LinearLayout contentArea;
    private int selectedIndex = -1;

    private final int BG = Color.rgb(32, 33, 36);
    private final int CARD = Color.rgb(48, 49, 54);
    private final int ACCENT = Color.rgb(0, 188, 170);
    private final int TEXT = Color.WHITE;
    private final int MUTED = Color.rgb(185, 185, 190);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildShell();
        showHome();
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_PERMISSION);
        }
    }

    private void buildShell() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);

        contentArea = new LinearLayout(this);
        contentArea.setOrientation(LinearLayout.VERTICAL);
        contentArea.setPadding(dp(16), dp(16), dp(16), dp(8));
        root.addView(contentArea, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setGravity(Gravity.CENTER);
        nav.setPadding(dp(6), dp(8), dp(6), dp(8));
        nav.setBackgroundColor(Color.rgb(38, 39, 43));
        root.addView(nav, new LinearLayout.LayoutParams(-1, -2));

        nav.addView(navBtn("Home", v -> showHome()), new LinearLayout.LayoutParams(0, -2, 1));
        nav.addView(navBtn("Files", v -> showFiles()), new LinearLayout.LayoutParams(0, -2, 1));
        nav.addView(navBtn("Tools", v -> showTools()), new LinearLayout.LayoutParams(0, -2, 1));
        nav.addView(navBtn("Me", v -> showMe()), new LinearLayout.LayoutParams(0, -2, 1));

        setContentView(root);
    }

    private void showHome() {
        contentArea.removeAllViews();

        TextView search = boxText("Search documents", 18, MUTED, CARD);
        search.setPadding(dp(18), dp(14), dp(18), dp(14));
        contentArea.addView(search, new LinearLayout.LayoutParams(-1, -2));

        GridLayout quick = new GridLayout(this);
        quick.setColumnCount(4);
        quick.setPadding(0, dp(16), 0, dp(12));
        contentArea.addView(quick, new LinearLayout.LayoutParams(-1, -2));
        quick.addView(tool("Smart Scan", v -> openCamera()));
        quick.addView(tool("PDF Tools", v -> showTools()));
        quick.addView(tool("Import\nImages", v -> openGallery()));
        quick.addView(tool("Extract\nText", v -> toast("OCR will be added in V2.1")));
        quick.addView(tool("ID Cards", v -> toast("ID Cards coming soon")));
        quick.addView(tool("Enhance", v -> applyEnhance()));
        quick.addView(tool("B & W", v -> applyBlackWhite()));
        quick.addView(tool("All Tools", v -> showTools()));

        TextView recentTitle = heading("Recents");
        contentArea.addView(recentTitle);

        LinearLayout recentCard = new LinearLayout(this);
        recentCard.setOrientation(LinearLayout.VERTICAL);
        recentCard.setBackgroundColor(CARD);
        recentCard.setPadding(dp(14), dp(14), dp(14), dp(14));
        contentArea.addView(recentCard, new LinearLayout.LayoutParams(-1, 0, 1));

        preview = new ImageView(this);
        preview.setBackgroundColor(Color.WHITE);
        preview.setScaleType(ImageView.ScaleType.FIT_CENTER);
        recentCard.addView(preview, new LinearLayout.LayoutParams(-1, 0, 1));

        status = new TextView(this);
        status.setTextColor(TEXT);
        status.setTextSize(15);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, dp(10), 0, dp(10));
        recentCard.addView(status, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.CENTER);
        recentCard.addView(actions, new LinearLayout.LayoutParams(-1, -2));
        actions.addView(actionBtn("Share PDF", v -> createPdf()));
        actions.addView(actionBtn("Camera", v -> openCamera()));

        Button camera = new Button(this);
        camera.setText("📷");
        camera.setTextSize(28);
        camera.setTextColor(Color.WHITE);
        camera.setBackgroundColor(ACCENT);
        camera.setOnClickListener(v -> openCamera());
        contentArea.addView(camera, new LinearLayout.LayoutParams(-1, dp(58)));

        updatePreview();
    }

    private void showFiles() {
        contentArea.removeAllViews();
        contentArea.addView(heading("Files"));
        TextView info = paragraph("Scanned pages in this session: " + pages.size() + "\nCreate PDF to save your document in Downloads.");
        contentArea.addView(info);
        contentArea.addView(bigBtn("Create PDF in Downloads", v -> createPdf()));
        contentArea.addView(bigBtn("Clear All Pages", v -> clearAll()));
    }

    private void showTools() {
        contentArea.removeAllViews();
        ScrollView sv = new ScrollView(this);
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        sv.addView(wrap);
        contentArea.addView(sv, new LinearLayout.LayoutParams(-1, -1));

        addSection(wrap, "Convert", new String[]{"To Word", "To Excel", "To PPT", "PDF to Images"});
        addSection(wrap, "Import", new String[]{"Import Images", "Import Files"});
        addSection(wrap, "Edit", new String[]{"Sign", "Watermark", "Merge Files", "Extract PDF Pages", "Reorder Pages", "Lock"});
        addSection(wrap, "AI Process", new String[]{"Smart Erase", "Solver AI", "Enhance Documents", "Restore Photo"});
        addSection(wrap, "Scan", new String[]{"ID Cards", "Extract Text", "Book", "Whiteboard", "Scan Code", "Slides"});

        wrap.addView(bigBtn("Enhance Current Page", v -> applyEnhance()));
        wrap.addView(bigBtn("Black & White Current Page", v -> applyBlackWhite()));
        wrap.addView(bigBtn("Rotate Current Page", v -> rotatePage()));
        wrap.addView(bigBtn("Remove Current Page", v -> removePage()));
    }

    private void showMe() {
        contentArea.removeAllViews();
        contentArea.addView(heading("Doc Scanner"));
        contentArea.addView(paragraph("Version 2.0\nOffline document scanner for camera/gallery, enhancement and PDF creation.\n\nMore tools like OCR, watermark, signature and PDF lock can be added in next versions."));
    }

    private void addSection(LinearLayout parent, String title, String[] labels) {
        parent.addView(heading(title));
        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(4);
        parent.addView(grid, new LinearLayout.LayoutParams(-1, -2));
        for (String label : labels) {
            if (label.equals("Import Images")) grid.addView(tool(label, v -> openGallery()));
            else grid.addView(tool(label, v -> toast(label + " coming soon")));
        }
    }

    private Button navBtn(String text, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(12);
        b.setTextColor(TEXT);
        b.setBackgroundColor(Color.TRANSPARENT);
        b.setOnClickListener(listener);
        return b;
    }

    private TextView tool(String text, View.OnClickListener listener) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(TEXT);
        t.setTextSize(12);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(4), dp(14), dp(4), dp(14));
        t.setBackgroundColor(CARD);
        t.setOnClickListener(listener);
        GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
        lp.width = getResources().getDisplayMetrics().widthPixels / 4 - dp(12);
        lp.setMargins(dp(4), dp(4), dp(4), dp(4));
        t.setLayoutParams(lp);
        return t;
    }

    private Button actionBtn(String text, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setBackgroundColor(Color.rgb(75, 76, 82));
        b.setOnClickListener(listener);
        return b;
    }

    private Button bigBtn(String text, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(16);
        b.setTextColor(TEXT);
        b.setBackgroundColor(CARD);
        b.setPadding(dp(8), dp(10), dp(8), dp(10));
        b.setOnClickListener(listener);
        return b;
    }

    private TextView heading(String text) {
        TextView h = new TextView(this);
        h.setText(text);
        h.setTextColor(TEXT);
        h.setTextSize(22);
        h.setTypeface(Typeface.DEFAULT_BOLD);
        h.setPadding(0, dp(18), 0, dp(10));
        return h;
    }

    private TextView paragraph(String text) {
        TextView p = new TextView(this);
        p.setText(text);
        p.setTextColor(MUTED);
        p.setTextSize(15);
        p.setPadding(0, dp(8), 0, dp(12));
        return p;
    }

    private TextView boxText(String text, int size, int color, int bg) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextSize(size);
        v.setTextColor(color);
        v.setBackgroundColor(bg);
        return v;
    }

    private void openCamera() {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (intent.resolveActivity(getPackageManager()) != null) startActivityForResult(intent, REQ_CAMERA);
        else toast("Camera app not found");
    }

    private void openGallery() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, REQ_GALLERY);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null) return;
        try {
            Bitmap bmp = null;
            if (requestCode == REQ_CAMERA) {
                Object obj = data.getExtras() != null ? data.getExtras().get("data") : null;
                if (obj instanceof Bitmap) bmp = (Bitmap) obj;
            } else if (requestCode == REQ_GALLERY) {
                Uri uri = data.getData();
                if (uri != null) {
                    InputStream is = getContentResolver().openInputStream(uri);
                    bmp = BitmapFactory.decodeStream(is);
                    if (is != null) is.close();
                }
            }
            if (bmp != null) {
                pages.add(scaleForMemory(bmp));
                selectedIndex = pages.size() - 1;
                updatePreview();
                toast("Page added");
            }
        } catch (Exception e) {
            toast("Failed to add page: " + e.getMessage());
        }
    }

    private Bitmap scaleForMemory(Bitmap src) {
        int max = 1600;
        int w = src.getWidth();
        int h = src.getHeight();
        if (w <= max && h <= max) return src;
        float ratio = Math.min((float) max / w, (float) max / h);
        return Bitmap.createScaledBitmap(src, Math.round(w * ratio), Math.round(h * ratio), true);
    }

    private void updatePreview() {
        if (preview == null || status == null) return;
        if (selectedIndex >= 0 && selectedIndex < pages.size()) {
            preview.setImageBitmap(pages.get(selectedIndex));
            status.setText("Page " + (selectedIndex + 1) + " of " + pages.size());
        } else {
            preview.setImageDrawable(null);
            status.setText("No page added yet");
        }
    }

    private Bitmap current() {
        if (selectedIndex < 0 || selectedIndex >= pages.size()) {
            toast("Add a page first");
            return null;
        }
        return pages.get(selectedIndex);
    }

    private void applyEnhance() {
        Bitmap src = current();
        if (src == null) return;
        Bitmap out = Bitmap.createBitmap(src.getWidth(), src.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(out);
        Paint paint = new Paint();
        ColorMatrix matrix = new ColorMatrix(new float[]{1.25f,0,0,0,10, 0,1.25f,0,0,10, 0,0,1.25f,0,10, 0,0,0,1,0});
        paint.setColorFilter(new ColorMatrixColorFilter(matrix));
        canvas.drawBitmap(src, 0, 0, paint);
        pages.set(selectedIndex, out);
        updatePreview();
    }

    private void applyBlackWhite() {
        Bitmap src = current();
        if (src == null) return;
        Bitmap out = Bitmap.createBitmap(src.getWidth(), src.getHeight(), Bitmap.Config.ARGB_8888);
        for (int y = 0; y < src.getHeight(); y++) {
            for (int x = 0; x < src.getWidth(); x++) {
                int c = src.getPixel(x, y);
                int gray = (Color.red(c) + Color.green(c) + Color.blue(c)) / 3;
                int bw = gray > 145 ? 255 : 0;
                out.setPixel(x, y, Color.rgb(bw, bw, bw));
            }
        }
        pages.set(selectedIndex, out);
        updatePreview();
    }

    private void rotatePage() {
        Bitmap src = current();
        if (src == null) return;
        Bitmap out = Bitmap.createBitmap(src.getHeight(), src.getWidth(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(out);
        canvas.rotate(90, out.getWidth() / 2f, out.getHeight() / 2f);
        canvas.drawBitmap(src, (out.getWidth() - src.getWidth()) / 2f, (out.getHeight() - src.getHeight()) / 2f, null);
        pages.set(selectedIndex, out);
        updatePreview();
    }

    private void removePage() {
        if (selectedIndex >= 0 && selectedIndex < pages.size()) {
            pages.remove(selectedIndex);
            selectedIndex = pages.size() - 1;
            updatePreview();
        } else toast("No page to remove");
    }

    private void clearAll() {
        pages.clear();
        selectedIndex = -1;
        updatePreview();
        toast("All pages cleared");
    }

    private void createPdf() {
        if (pages.isEmpty()) {
            toast("Add pages first");
            return;
        }
        try {
            String fileName = "DocScanner_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".pdf";
            OutputStream os;
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Downloads.DISPLAY_NAME, fileName);
                values.put(MediaStore.Downloads.MIME_TYPE, "application/pdf");
                values.put(MediaStore.Downloads.RELATIVE_PATH, "Download/DocScanner");
                Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                os = getContentResolver().openOutputStream(uri);
            } else {
                File dir = new File(android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS), "DocScanner");
                if (!dir.exists()) dir.mkdirs();
                os = new FileOutputStream(new File(dir, fileName));
            }
            PdfDocument pdf = new PdfDocument();
            for (int i = 0; i < pages.size(); i++) {
                Bitmap bmp = pages.get(i);
                PdfDocument.PageInfo info = new PdfDocument.PageInfo.Builder(bmp.getWidth(), bmp.getHeight(), i + 1).create();
                PdfDocument.Page page = pdf.startPage(info);
                page.getCanvas().drawBitmap(bmp, 0, 0, null);
                pdf.finishPage(page);
            }
            pdf.writeTo(os);
            pdf.close();
            if (os != null) os.close();
            toast("PDF saved: Downloads/DocScanner/" + fileName);
        } catch (Exception e) {
            toast("PDF failed: " + e.getMessage());
        }
    }

    private void toast(String msg) { Toast.makeText(this, msg, Toast.LENGTH_LONG).show(); }
    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }
}
