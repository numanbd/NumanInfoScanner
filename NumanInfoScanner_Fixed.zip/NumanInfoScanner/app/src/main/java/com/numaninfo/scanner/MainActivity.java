package com.numaninfo.scanner;

import android.Manifest;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;


import java.io.File;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_CAMERA = 11;
    private static final int REQ_GALLERY = 12;
    private static final int REQ_PERMISSION = 99;

    private final ArrayList<String> pagePaths = new ArrayList<>();
    private ArrayAdapter<String> adapter;
    private ImageView preview;
    private TextView status;
    private EditText docName;
    private int selectedIndex = -1;
    private Uri cameraUri;
    private File lastPdfFile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestBasicPermissions();
        buildUi();
        loadLastPdf();
    }

    private void buildUi() {
        ScrollView scrollView = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(16), dp(14), dp(16));
        root.setBackgroundColor(Color.rgb(243, 246, 251));
        scrollView.addView(root);

        TextView title = new TextView(this);
        title.setText("Numan Info Scanner");
        title.setTextSize(26);
        title.setTextColor(Color.rgb(4, 54, 74));
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 0, 0, dp(4));
        title.setTypeface(null, 1);
        root.addView(title);

        TextView sub = new TextView(this);
        sub.setText("Offline Document Scanner • PDF Maker • JPG Share");
        sub.setTextSize(14);
        sub.setTextColor(Color.DKGRAY);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, 0, 0, dp(12));
        root.addView(sub);

        docName = new EditText(this);
        docName.setHint("Document name, e.g. Eid Gift List");
        docName.setSingleLine(true);
        docName.setText("NumanScan_" + new SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(new Date()));
        docName.setPadding(dp(12), dp(8), dp(12), dp(8));
        root.addView(docName, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout row1 = row();
        row1.addView(primaryButton("Camera Scan", v -> openCamera()), weight());
        row1.addView(primaryButton("Import Image", v -> openGallery()), weight());
        root.addView(row1);

        preview = new ImageView(this);
        preview.setBackgroundColor(Color.WHITE);
        preview.setScaleType(ImageView.ScaleType.FIT_CENTER);
        preview.setAdjustViewBounds(true);
        LinearLayout.LayoutParams imgParams = new LinearLayout.LayoutParams(-1, dp(330));
        imgParams.setMargins(0, dp(12), 0, dp(8));
        root.addView(preview, imgParams);

        status = new TextView(this);
        status.setText("No pages yet. Scan or import an image.");
        status.setTextSize(14);
        status.setTextColor(Color.DKGRAY);
        status.setPadding(dp(6), dp(6), dp(6), dp(8));
        root.addView(status);

        LinearLayout row2 = row();
        row2.addView(secondaryButton("Auto Crop", v -> applyToSelected("crop")), weight());
        row2.addView(secondaryButton("Clear Filter", v -> applyToSelected("clear")), weight());
        root.addView(row2);

        LinearLayout row3 = row();
        row3.addView(secondaryButton("B/W Filter", v -> applyToSelected("bw")), weight());
        row3.addView(secondaryButton("Enhance", v -> applyToSelected("enhance")), weight());
        root.addView(row3);

        LinearLayout row4 = row();
        row4.addView(secondaryButton("Rotate", v -> applyToSelected("rotate")), weight());
        row4.addView(secondaryButton("Remove Page", v -> removeSelected()), weight());
        root.addView(row4);

        LinearLayout row5 = row();
        row5.addView(primaryButton("Create PDF", v -> exportPdf()), weight());
        row5.addView(primaryButton("Share PDF", v -> shareLastPdf()), weight());
        root.addView(row5);

        TextView listTitle = new TextView(this);
        listTitle.setText("Scanned Pages");
        listTitle.setTextSize(18);
        listTitle.setTypeface(null, 1);
        listTitle.setTextColor(Color.rgb(4, 54, 74));
        listTitle.setPadding(0, dp(12), 0, dp(4));
        root.addView(listTitle);

        ListView list = new ListView(this);
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_activated_1, getPageLabels());
        list.setAdapter(adapter);
        list.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
        list.setOnItemClickListener((AdapterView<?> parent, View view, int position, long id) -> {
            selectedIndex = position;
            showSelected();
        });
        root.addView(list, new LinearLayout.LayoutParams(-1, dp(180)));

        TextView footer = new TextView(this);
        footer.setText("V1 features: camera/gallery scan, multi-page PDF, B/W, enhance, rotate, remove page, share PDF. OCR, password PDF, signature and cloud backup can be added in V2.");
        footer.setTextSize(13);
        footer.setTextColor(Color.GRAY);
        footer.setPadding(0, dp(10), 0, 0);
        root.addView(footer);

        setContentView(scrollView);
    }

    private LinearLayout row() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(6), 0, 0);
        return row;
    }

    private LinearLayout.LayoutParams weight() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(48), 1);
        p.setMargins(dp(4), 0, dp(4), 0);
        return p;
    }

    private Button primaryButton(String text, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(13);
        b.setAllCaps(false);
        b.setBackgroundResource(com.numaninfo.scanner.R.drawable.button_primary);
        b.setOnClickListener(listener);
        return b;
    }

    private Button secondaryButton(String text, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.rgb(4, 54, 74));
        b.setTextSize(13);
        b.setAllCaps(false);
        b.setBackgroundResource(com.numaninfo.scanner.R.drawable.button_secondary);
        b.setOnClickListener(listener);
        return b;
    }

    private void requestBasicPermissions() {
        ArrayList<String> perms = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            perms.add(Manifest.permission.CAMERA);
        }
        if (Build.VERSION.SDK_INT >= 33) {
            if (checkSelfPermission(Manifest.permission.READ_MEDIA_IMAGES) != PackageManager.PERMISSION_GRANTED) perms.add(Manifest.permission.READ_MEDIA_IMAGES);
        } else if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            perms.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        }
        if (!perms.isEmpty()) requestPermissions(perms.toArray(new String[0]), REQ_PERMISSION);
    }

    private void openCamera() {
        try {
            requestBasicPermissions();
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, "scan_" + System.currentTimeMillis() + ".jpg");
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            if (Build.VERSION.SDK_INT >= 29) {
                values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/NumanInfoScanner");
            }
            cameraUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            i.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            startActivityForResult(i, REQ_CAMERA);
        } catch (Exception e) {
            toast("Camera open failed: " + e.getMessage());
        }
    }

    private void openGallery() {
        Intent i = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        i.setType("image/*");
        startActivityForResult(i, REQ_GALLERY);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK) return;
        try {
            if (requestCode == REQ_CAMERA && cameraUri != null) {
                Bitmap bmp = loadBitmapFromUri(cameraUri);
                String path = saveBitmap(bmp, "camera_" + System.currentTimeMillis() + ".jpg");
                addPagePath(path);
            } else if (requestCode == REQ_GALLERY && data != null && data.getData() != null) {
                Bitmap bmp = loadBitmapFromUri(data.getData());
                String path = saveBitmap(bmp, "import_" + System.currentTimeMillis() + ".jpg");
                addPagePath(path);
            }
        } catch (Exception e) {
            toast("Image load failed: " + e.getMessage());
        }
    }

    private void addPageFromFile(File file) throws Exception {
        Bitmap bmp = decodeSampledBitmap(file.getAbsolutePath(), 1800);
        String path = saveBitmap(bmp, "scan_" + System.currentTimeMillis() + ".jpg");
        addPagePath(path);
    }

    private void addPagePath(String path) {
        pagePaths.add(path);
        selectedIndex = pagePaths.size() - 1;
        refreshList();
        showSelected();
        status.setText(pagePaths.size() + " page(s) ready. Select a page to edit, then create PDF.");
    }

    private void showSelected() {
        if (selectedIndex < 0 || selectedIndex >= pagePaths.size()) return;
        Bitmap bmp = decodeSampledBitmap(pagePaths.get(selectedIndex), 1600);
        preview.setImageBitmap(bmp);
        status.setText("Selected page " + (selectedIndex + 1) + " of " + pagePaths.size());
    }

    private void applyToSelected(String mode) {
        if (selectedIndex < 0 || selectedIndex >= pagePaths.size()) { toast("Select a page first"); return; }
        try {
            Bitmap bmp = decodeSampledBitmap(pagePaths.get(selectedIndex), 2200);
            Bitmap out;
            switch (mode) {
                case "bw": out = blackWhite(bmp); break;
                case "enhance": out = enhance(bmp); break;
                case "rotate": out = rotate90(bmp); break;
                case "crop": out = autoCrop(bmp); break;
                default: out = bmp; break;
            }
            String path = saveBitmap(out, "edit_" + System.currentTimeMillis() + ".jpg");
            pagePaths.set(selectedIndex, path);
            showSelected();
            toast("Applied: " + mode);
        } catch (Exception e) {
            toast("Edit failed: " + e.getMessage());
        }
    }

    private void removeSelected() {
        if (selectedIndex < 0 || selectedIndex >= pagePaths.size()) { toast("Select a page first"); return; }
        pagePaths.remove(selectedIndex);
        if (pagePaths.isEmpty()) {
            selectedIndex = -1;
            preview.setImageDrawable(null);
            status.setText("No pages yet.");
        } else {
            selectedIndex = Math.min(selectedIndex, pagePaths.size() - 1);
            showSelected();
        }
        refreshList();
    }

    private void exportPdf() {
        if (pagePaths.isEmpty()) { toast("Add pages first"); return; }
        try {
            String name = docName.getText().toString().trim();
            if (name.length() == 0) name = "NumanScan_" + System.currentTimeMillis();
            name = name.replaceAll("[^a-zA-Z0-9_ -]", "_");
            File dir = new File(getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), "pdf");
            if (!dir.exists()) dir.mkdirs();
            File pdf = new File(dir, name + ".pdf");
            PdfDocument document = new PdfDocument();
            Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
            int pageW = 595;
            int pageH = 842;
            for (int i = 0; i < pagePaths.size(); i++) {
                Bitmap bmp = decodeSampledBitmap(pagePaths.get(i), 2200);
                PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(pageW, pageH, i + 1).create();
                PdfDocument.Page page = document.startPage(pageInfo);
                Canvas c = page.getCanvas();
                c.drawColor(Color.WHITE);
                Rect dst = fitCenter(bmp.getWidth(), bmp.getHeight(), pageW - 40, pageH - 40, 20, 20);
                c.drawBitmap(bmp, null, dst, paint);
                document.finishPage(page);
            }
            FileOutputStream fos = new FileOutputStream(pdf);
            document.writeTo(fos);
            fos.close();
            document.close();
            lastPdfFile = pdf;
            saveLastPdf(pdf.getAbsolutePath());
            toast("PDF created: " + pdf.getName());
            shareFile(pdf, "application/pdf");
        } catch (Exception e) {
            toast("PDF failed: " + e.getMessage());
        }
    }

    private Rect fitCenter(int bw, int bh, int maxW, int maxH, int left, int top) {
        float scale = Math.min(maxW / (float) bw, maxH / (float) bh);
        int w = Math.round(bw * scale);
        int h = Math.round(bh * scale);
        int x = left + (maxW - w) / 2;
        int y = top + (maxH - h) / 2;
        return new Rect(x, y, x + w, y + h);
    }

    private void shareLastPdf() {
        if (lastPdfFile == null || !lastPdfFile.exists()) { toast("Create PDF first"); return; }
        shareFile(lastPdfFile, "application/pdf");
    }

    private void shareFile(File file, String mime) {
        try {
            Uri uri = copyPdfToDownloads(file);
            Intent share = new Intent(Intent.ACTION_SEND);
            share.setType(mime);
            share.putExtra(Intent.EXTRA_STREAM, uri);
            share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(share, "Share with"));
        } catch (Exception e) {
            toast("Share failed: " + e.getMessage());
        }
    }

    private Uri copyPdfToDownloads(File file) throws Exception {
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Downloads.DISPLAY_NAME, file.getName());
            values.put(MediaStore.Downloads.MIME_TYPE, "application/pdf");
            values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/NumanInfoScanner");
            Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            OutputStream out = getContentResolver().openOutputStream(uri);
            FileInputStream in = new FileInputStream(file);
            byte[] buffer = new byte[8192];
            int len;
            while ((len = in.read(buffer)) > 0) out.write(buffer, 0, len);
            in.close();
            out.close();
            return uri;
        }
        return Uri.fromFile(file);
    }

    private Bitmap loadBitmapFromUri(Uri uri) throws Exception {
        ContentResolver cr = getContentResolver();
        InputStream in = cr.openInputStream(uri);
        Bitmap bmp = BitmapFactory.decodeStream(in);
        if (in != null) in.close();
        return resizeIfNeeded(bmp, 2200);
    }

    private Bitmap decodeSampledBitmap(String path, int maxSize) {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(path, o);
        int sample = 1;
        while (o.outWidth / sample > maxSize || o.outHeight / sample > maxSize) sample *= 2;
        BitmapFactory.Options o2 = new BitmapFactory.Options();
        o2.inSampleSize = sample;
        return BitmapFactory.decodeFile(path, o2);
    }

    private Bitmap resizeIfNeeded(Bitmap bmp, int max) {
        if (bmp == null) return null;
        int w = bmp.getWidth(), h = bmp.getHeight();
        if (w <= max && h <= max) return bmp;
        float scale = Math.min(max / (float) w, max / (float) h);
        return Bitmap.createScaledBitmap(bmp, Math.round(w * scale), Math.round(h * scale), true);
    }

    private String saveBitmap(Bitmap bmp, String filename) throws Exception {
        File dir = new File(getExternalFilesDir(Environment.DIRECTORY_PICTURES), "pages");
        if (!dir.exists()) dir.mkdirs();
        File out = new File(dir, filename);
        FileOutputStream fos = new FileOutputStream(out);
        bmp.compress(Bitmap.CompressFormat.JPEG, 92, fos);
        fos.close();
        return out.getAbsolutePath();
    }

    private Bitmap blackWhite(Bitmap src) {
        Bitmap out = Bitmap.createBitmap(src.getWidth(), src.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(out);
        Paint paint = new Paint();
        ColorMatrix cm = new ColorMatrix();
        cm.setSaturation(0);
        ColorMatrix contrast = new ColorMatrix(new float[]{
                1.45f, 0, 0, 0, -35,
                0, 1.45f, 0, 0, -35,
                0, 0, 1.45f, 0, -35,
                0, 0, 0, 1, 0});
        cm.postConcat(contrast);
        paint.setColorFilter(new ColorMatrixColorFilter(cm));
        canvas.drawBitmap(src, 0, 0, paint);
        return out;
    }

    private Bitmap enhance(Bitmap src) {
        Bitmap out = Bitmap.createBitmap(src.getWidth(), src.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(out);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        ColorMatrix cm = new ColorMatrix(new float[]{
                1.18f, 0, 0, 0, 10,
                0, 1.18f, 0, 0, 10,
                0, 0, 1.18f, 0, 10,
                0, 0, 0, 1, 0});
        paint.setColorFilter(new ColorMatrixColorFilter(cm));
        canvas.drawBitmap(src, 0, 0, paint);
        return out;
    }

    private Bitmap rotate90(Bitmap src) {
        android.graphics.Matrix matrix = new android.graphics.Matrix();
        matrix.postRotate(90);
        return Bitmap.createBitmap(src, 0, 0, src.getWidth(), src.getHeight(), matrix, true);
    }

    private Bitmap autoCrop(Bitmap src) {
        int w = src.getWidth();
        int h = src.getHeight();
        int left = w, top = h, right = 0, bottom = 0;
        int step = Math.max(1, Math.min(w, h) / 600);
        for (int y = 0; y < h; y += step) {
            for (int x = 0; x < w; x += step) {
                int p = src.getPixel(x, y);
                int r = Color.red(p), g = Color.green(p), b = Color.blue(p);
                boolean notWhite = !(r > 235 && g > 235 && b > 235);
                if (notWhite) {
                    if (x < left) left = x;
                    if (x > right) right = x;
                    if (y < top) top = y;
                    if (y > bottom) bottom = y;
                }
            }
        }
        int pad = dp(8);
        left = Math.max(0, left - pad); top = Math.max(0, top - pad);
        right = Math.min(w, right + pad); bottom = Math.min(h, bottom + pad);
        if (right <= left || bottom <= top || (right-left) < w * 0.25 || (bottom-top) < h * 0.25) return src;
        return Bitmap.createBitmap(src, left, top, right - left, bottom - top);
    }

    private ArrayList<String> getPageLabels() {
        ArrayList<String> labels = new ArrayList<>();
        for (int i = 0; i < pagePaths.size(); i++) labels.add("Page " + (i + 1));
        return labels;
    }

    private void refreshList() {
        adapter.clear();
        adapter.addAll(getPageLabels());
        adapter.notifyDataSetChanged();
    }

    private void saveLastPdf(String path) {
        getSharedPreferences("scanner", MODE_PRIVATE).edit().putString("last_pdf", path).apply();
    }

    private void loadLastPdf() {
        SharedPreferences sp = getSharedPreferences("scanner", MODE_PRIVATE);
        String path = sp.getString("last_pdf", null);
        if (path != null) {
            File f = new File(path);
            if (f.exists()) lastPdfFile = f;
        }
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }
    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }
}
