package com.numan.docscanner;

import android.Manifest;
import android.app.*;
import android.os.*;
import android.provider.MediaStore;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    final int REQ_CAMERA=10, REQ_GALLERY=11, REQ_PERM=99;
    LinearLayout root, content, bottomBar;
    ImageView preview;
    TextView title, subtitle, pageInfo;
    ArrayList<Bitmap> pages = new ArrayList<>();
    ArrayList<String> recent = new ArrayList<>();
    int current = -1;
    int bg = Color.rgb(32,34,36), card = Color.rgb(50,52,55), green = Color.rgb(0,168,132);

    @Override public void onCreate(Bundle b){ super.onCreate(b); requestPerms(); loadRecent(); showHome(); }

    void requestPerms(){ if(Build.VERSION.SDK_INT>=23) requestPermissions(new String[]{Manifest.permission.CAMERA, Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_EXTERNAL_STORAGE}, REQ_PERM); }

    TextView tv(String text, int sp, int color, int style){ TextView v=new TextView(this); v.setText(text); v.setTextSize(sp); v.setTextColor(color); v.setTypeface(Typeface.DEFAULT, style); v.setPadding(16,10,16,10); return v; }
    Button btn(String text){ Button b=new Button(this); b.setText(text); b.setTextSize(15); b.setTextColor(Color.WHITE); b.setAllCaps(false); b.setBackgroundColor(card); b.setPadding(8,8,8,8); return b; }

    void base(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(bg); setContentView(root);
        content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(18,18,18,8);
        ScrollView sv=new ScrollView(this); sv.addView(content); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        bottomBar=new LinearLayout(this); bottomBar.setOrientation(LinearLayout.HORIZONTAL); bottomBar.setGravity(Gravity.CENTER); bottomBar.setBackgroundColor(Color.rgb(28,29,31));
        root.addView(bottomBar,new LinearLayout.LayoutParams(-1,78));
        addNav("Home", ()->showHome()); addNav("Files", ()->showFiles()); addNav("Tools", ()->showTools()); addNav("Me", ()->showMe());
    }
    void addNav(String s, final Runnable r){ TextView v=tv(s,14,Color.LTGRAY,Typeface.BOLD); v.setGravity(Gravity.CENTER); v.setOnClickListener(x->r.run()); bottomBar.addView(v,new LinearLayout.LayoutParams(0,-1,1)); }

    void header(){
        title=tv("Doc Scanner",30,Color.WHITE,Typeface.BOLD); content.addView(title);
        TextView search=tv("🔍  Search documents",16,Color.GRAY,Typeface.NORMAL); search.setBackgroundColor(Color.rgb(23,24,26)); content.addView(search,new LinearLayout.LayoutParams(-1,58));
    }

    void showHome(){ base(); header();
        GridLayout grid=new GridLayout(this); grid.setColumnCount(4); grid.setPadding(0,20,0,20); content.addView(grid);
        addTool(grid,"📷\nSmart Scan",()->openCamera());
        addTool(grid,"🖼️\nImport Images",()->openGallery());
        addTool(grid,"📄\nPDF Tools",()->createPdf());
        addTool(grid,"🔤\nExtract Text",()->toast("OCR আসবে V4-তে. Offline OCR করতে ML Kit/OpenCV লাগবে."));
        addTool(grid,"🪪\nID Cards",()->toast("ID Card mode selected. সামনে-পেছন ২ পেজ scan করুন."));
        addTool(grid,"✨\nEnhance",()->enhance());
        addTool(grid,"✒️\nSign",()->addTextOverlay("Signature"));
        addTool(grid,"⋯\nAll Tools",()->showTools());
        content.addView(tv("Recents",22,Color.WHITE,Typeface.BOLD));
        showRecentList();
        TextView cam=tv("📷",38,Color.WHITE,Typeface.BOLD); cam.setGravity(Gravity.CENTER); cam.setBackgroundColor(green); cam.setOnClickListener(v->openCamera()); content.addView(cam,new LinearLayout.LayoutParams(-1,80));
    }

    void addTool(GridLayout grid, String label, final Runnable r){ TextView v=tv(label,13,Color.WHITE,Typeface.NORMAL); v.setGravity(Gravity.CENTER); v.setBackgroundColor(card); v.setOnClickListener(x->r.run()); GridLayout.LayoutParams lp=new GridLayout.LayoutParams(); lp.width=getResources().getDisplayMetrics().widthPixels/4-18; lp.height=110; lp.setMargins(5,6,5,6); grid.addView(v,lp); }

    void showWorkspace(){ base(); title=tv("Doc Scanner",28,Color.WHITE,Typeface.BOLD); title.setGravity(Gravity.CENTER); content.addView(title); subtitle=tv("Smart crop, enhance, B&W and PDF maker",15,Color.LTGRAY,Typeface.NORMAL); subtitle.setGravity(Gravity.CENTER); content.addView(subtitle);
        preview=new ImageView(this); preview.setBackgroundColor(Color.WHITE); preview.setScaleType(ImageView.ScaleType.FIT_CENTER); content.addView(preview,new LinearLayout.LayoutParams(-1,520));
        pageInfo=tv("No page added yet",18,Color.WHITE,Typeface.BOLD); pageInfo.setGravity(Gravity.CENTER); content.addView(pageInfo);
        String[] names={"Scan with Camera","Import from Gallery","Smart Crop","Enhance / Clear","Black & White","Rotate Page","Add Watermark","Add Signature","Create PDF in Downloads","Remove Current Page","Clear All Pages"};
        for(String n:names){ Button b=btn(n); content.addView(b,new LinearLayout.LayoutParams(-1,66));
            if(n.startsWith("Scan")) b.setOnClickListener(v->openCamera()); else if(n.startsWith("Import")) b.setOnClickListener(v->openGallery()); else if(n.startsWith("Smart")) b.setOnClickListener(v->smartCrop()); else if(n.startsWith("Enhance")) b.setOnClickListener(v->enhance()); else if(n.startsWith("Black")) b.setOnClickListener(v->bw()); else if(n.startsWith("Rotate")) b.setOnClickListener(v->rotate()); else if(n.startsWith("Add Watermark")) b.setOnClickListener(v->addTextOverlay("Doc Scanner")); else if(n.startsWith("Add Signature")) b.setOnClickListener(v->addTextOverlay("Signed")); else if(n.startsWith("Create")) b.setOnClickListener(v->createPdf()); else if(n.startsWith("Remove")) b.setOnClickListener(v->removePage()); else if(n.startsWith("Clear")) b.setOnClickListener(v->{pages.clear(); current=-1; updatePreview();});
        }
        updatePreview();
    }

    void showFiles(){ base(); content.addView(tv("Files",28,Color.WHITE,Typeface.BOLD)); showRecentList(); }
    void showTools(){ base(); content.addView(tv("Tools",28,Color.WHITE,Typeface.BOLD)); GridLayout g=new GridLayout(this); g.setColumnCount(3); content.addView(g); String[] tools={"📷\nSmart Scan","🖼️\nImport Images","📄\nCreate PDF","✨\nEnhance","⚫\nBlack & White","🔄\nRotate","✒️\nSign","💧\nWatermark","🔒\nLock PDF","📚\nBook Scan","🪪\nID Cards","🔤\nOCR Text"}; for(String t:tools) addTool(g,t,()->handleTool(t)); }
    void showMe(){ base(); content.addView(tv("Me",28,Color.WHITE,Typeface.BOLD)); content.addView(tv("Doc Scanner V3\nOffline document scanner.\nWorking: Camera, Gallery, Smart Crop, Enhance, B&W, Rotate, Watermark, Signature, PDF export, Recent files.",16,Color.LTGRAY,Typeface.NORMAL)); }
    void handleTool(String t){ if(t.contains("Scan")) openCamera(); else if(t.contains("Import")) openGallery(); else if(t.contains("PDF")) createPdf(); else if(t.contains("Enhance")) enhance(); else if(t.contains("Black")) bw(); else if(t.contains("Rotate")) rotate(); else if(t.contains("Sign")) addTextOverlay("Signed"); else if(t.contains("Watermark")) addTextOverlay("Doc Scanner"); else toast("এই tool V4-তে fully working করা হবে."); }

    void showRecentList(){ if(recent.size()==0){ content.addView(tv("No recent PDF yet",16,Color.GRAY,Typeface.NORMAL)); return;} for(String p: recent){ TextView row=tv("📄  "+new File(p).getName()+"\n"+p,15,Color.WHITE,Typeface.NORMAL); row.setBackgroundColor(card); row.setOnClickListener(v->{ Intent in=new Intent(Intent.ACTION_VIEW); in.setDataAndType(Uri.fromFile(new File(p)),"application/pdf"); in.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); try{startActivity(in);}catch(Exception e){toast("PDF saved: "+p);} }); content.addView(row,new LinearLayout.LayoutParams(-1,90)); }}

    void openCamera(){ Intent i=new Intent(MediaStore.ACTION_IMAGE_CAPTURE); try{ startActivityForResult(i,REQ_CAMERA); }catch(Exception e){ toast("Camera open failed"); } }
    void openGallery(){ Intent i=new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI); startActivityForResult(i,REQ_GALLERY); }
    @Override protected void onActivityResult(int r,int c,Intent d){ super.onActivityResult(r,c,d); if(c!=RESULT_OK||d==null)return; try{ Bitmap bm=null; if(r==REQ_CAMERA){ Bundle ex=d.getExtras(); if(ex!=null) bm=(Bitmap)ex.get("data"); } else if(r==REQ_GALLERY){ bm=MediaStore.Images.Media.getBitmap(getContentResolver(), d.getData()); } if(bm!=null){ pages.add(bm.copy(Bitmap.Config.ARGB_8888,true)); current=pages.size()-1; showWorkspace(); } }catch(Exception e){toast("Image load failed: "+e.getMessage());}}

    void updatePreview(){ if(preview==null)return; if(current>=0&&current<pages.size()){ preview.setImageBitmap(pages.get(current)); pageInfo.setText("Page "+(current+1)+" of "+pages.size()); } else { preview.setImageBitmap(null); pageInfo.setText("No page added yet"); } }
    Bitmap cur(){ if(current<0||current>=pages.size()){ toast("আগে ছবি scan/import করুন"); return null;} return pages.get(current); }
    void replace(Bitmap b){ if(b!=null){ pages.set(current,b); updatePreview(); } }

    void smartCrop(){ Bitmap b=cur(); if(b==null)return; int w=b.getWidth(), h=b.getHeight(); int left=w/20, top=h/20, right=w-w/20, bottom=h-h/20; // safe crop
        replace(Bitmap.createBitmap(b,left,top,right-left,bottom-top)); toast("Smart crop applied"); }
    void enhance(){ Bitmap b=cur(); if(b==null)return; Bitmap out=b.copy(Bitmap.Config.ARGB_8888,true); for(int y=0;y<out.getHeight();y++) for(int x=0;x<out.getWidth();x++){ int c=out.getPixel(x,y); int r=Color.red(c),g=Color.green(c),bl=Color.blue(c); r=Math.min(255,(int)(r*1.18+12)); g=Math.min(255,(int)(g*1.18+12)); bl=Math.min(255,(int)(bl*1.18+12)); out.setPixel(x,y,Color.rgb(r,g,bl)); } replace(out); toast("Enhanced"); }
    void bw(){ Bitmap b=cur(); if(b==null)return; Bitmap out=b.copy(Bitmap.Config.ARGB_8888,true); for(int y=0;y<out.getHeight();y++) for(int x=0;x<out.getWidth();x++){ int c=out.getPixel(x,y); int gr=(Color.red(c)+Color.green(c)+Color.blue(c))/3; int v=gr>145?255:0; out.setPixel(x,y,Color.rgb(v,v,v)); } replace(out); toast("Black & White applied"); }
    void rotate(){ Bitmap b=cur(); if(b==null)return; Matrix m=new Matrix(); m.postRotate(90); replace(Bitmap.createBitmap(b,0,0,b.getWidth(),b.getHeight(),m,true)); }
    void removePage(){ if(current>=0){ pages.remove(current); if(current>=pages.size()) current=pages.size()-1; updatePreview(); } }
    void addTextOverlay(String text){ Bitmap b=cur(); if(b==null)return; Bitmap out=b.copy(Bitmap.Config.ARGB_8888,true); Canvas c=new Canvas(out); Paint p=new Paint(Paint.ANTI_ALIAS_FLAG); p.setColor(Color.argb(135,0,120,90)); p.setTextSize(Math.max(32,out.getWidth()/14)); p.setTypeface(Typeface.DEFAULT_BOLD); c.drawText(text, out.getWidth()/8, out.getHeight()-out.getHeight()/12, p); replace(out); toast(text+" added"); }

    void createPdf(){ if(pages.size()==0){ toast("আগে ছবি scan/import করুন"); return;} try{ File dir=Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS); if(!dir.exists())dir.mkdirs(); String name="DocScanner_"+new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(new Date())+".pdf"; File file=new File(dir,name); PdfDocument pdf=new PdfDocument(); for(Bitmap bm:pages){ int pw=595, ph=842; PdfDocument.PageInfo info=new PdfDocument.PageInfo.Builder(pw,ph,pdf.getPages().size()+1).create(); PdfDocument.Page page=pdf.startPage(info); Canvas canvas=page.getCanvas(); canvas.drawColor(Color.WHITE); Rect dst=fitRect(bm.getWidth(),bm.getHeight(),pw,ph); canvas.drawBitmap(bm,null,dst,null); pdf.finishPage(page); } FileOutputStream fos=new FileOutputStream(file); pdf.writeTo(fos); fos.close(); pdf.close(); recent.add(0,file.getAbsolutePath()); saveRecent(); toast("PDF saved in Downloads: "+name); }catch(Exception e){ toast("PDF failed: "+e.getMessage()); } }
    Rect fitRect(int w,int h,int pw,int ph){ float s=Math.min(pw/(float)w, ph/(float)h); int nw=(int)(w*s), nh=(int)(h*s); int l=(pw-nw)/2,t=(ph-nh)/2; return new Rect(l,t,l+nw,t+nh); }
    void saveRecent(){ getPreferences(0).edit().putString("recent", String.join("|", recent)).apply(); }
    void loadRecent(){ String s=getPreferences(0).getString("recent",""); if(!s.isEmpty()) recent.addAll(Arrays.asList(s.split("\\|"))); }
    void toast(String s){ Toast.makeText(this,s,Toast.LENGTH_LONG).show(); }
}
