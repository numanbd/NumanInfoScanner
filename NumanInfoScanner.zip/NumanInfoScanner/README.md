# Numan Info Scanner

Offline Android Document Scanner V1.

## V1 Features
- Camera scan
- Gallery image import
- Multiple page document
- Auto crop (basic white-border crop)
- Black & white filter
- Clear/enhance filter
- Rotate page
- Remove page
- Create PDF
- Share PDF

## Planned V2 Features
- OCR text extraction
- Search inside scanned documents
- Password protected PDF
- Signature and watermark
- Page reorder
- PDF compression
- ID card scan mode

## Build with GitHub Actions
Upload this ZIP to a GitHub repository root. Then create `.github/workflows/build-apk.yml` with the workflow included in this project or the workflow provided in ChatGPT.
